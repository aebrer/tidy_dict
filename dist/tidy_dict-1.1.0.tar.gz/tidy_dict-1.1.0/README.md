# TidyDict()

* By default, a non-existing key creates another TidyDict at that key.
* Prints in a non-garbage way (tabulated).
* use `.to_csv()` to get a CSV file
* use `to_dict()` to get a "normal" dictionary

# load_csv_to_tidydict()

* use this function to create a TidyDict from a csv
