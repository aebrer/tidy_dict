# NestedDict()

* By default, a non-existing key creates another NestedDict at that key.
* Prints in a non-garbage way (tabulated).
* use `.to_csv()` to get a CSV file
* use `to_dict()` to get a "normal" dictionary
